#include"main.h"
#include"Game.cpp"
using namespace std;

int main(int argc, char** argv) {
    Game g;
    g.Welcome();
    system("PAUSE");
}