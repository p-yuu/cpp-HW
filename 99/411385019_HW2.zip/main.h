#ifndef MAIN
#define MAIN

#include<iostream>
#include<string>
#include<vector>
#include<random>
#include<algorithm>
#include<map>
#include"Card.cpp"
using namespace std;

#endif